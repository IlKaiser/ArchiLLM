# Docker Mastery for Node.js Projects From a Docker Captain

[![Lint Code Base](https://github.com/BretFisher/docker-mastery-for-nodejs/actions/workflows/linter.yml/badge.svg)](https://github.com/BretFisher/docker-mastery-for-nodejs/actions/workflows/linter.yml)

This repository is for use in my Udemy Course [bretfisher.com/docker-mastery-for-nodejs](https://www.bretfisher.com/docker-mastery-for-nodejs)

Feel free to create issues or PRs if you find a problem with the repository.
Please use the Udemy course for lecture-specific support.

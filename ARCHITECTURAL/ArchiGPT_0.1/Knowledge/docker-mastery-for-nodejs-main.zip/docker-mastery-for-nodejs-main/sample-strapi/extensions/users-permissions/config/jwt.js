module.exports = {
  jwtSecret: process.env.JWT_SECRET || '750565f4-f99d-49da-96fc-295c573dd110'
};